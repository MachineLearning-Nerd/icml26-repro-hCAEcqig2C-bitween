int bresenham(int X, int Y) {
  vdistr(X, 0, 1000); 
  vdistr(Y, 0, 1000);
  assume(X >= 0);

  int v = 2 * Y - X, x = 0, y = 0;
  while (1) {
    assert(2*X*y + X - 2*Y*x - 2*Y + v == 0);
    
    if (!(x <= X)) break;
    if (v < 0) {
      v = v + 2 * Y;
    } else {
      v = v + 2 * (Y - X); y++;
    }
    x++;
  }
  assert(X - x + 1 == 0);
  assert(2*Y*x +2*Y -v -2*x*y -x +2*y +1==0);
  return v;
}