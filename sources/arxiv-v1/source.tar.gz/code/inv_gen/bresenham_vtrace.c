int bresenham(int X, int Y) {
  vdistr(X, 0, 1000); 
  vdistr(Y, 0, 1000);
  assume(X >= 0);
  
  int v = 2 * Y - X, x = 0, y = 0;
  while (1) {
    vtrace1(X, Y, x, y, v);
    
    if (!(x <= X)) break;
    if (v < 0) {
      v = v + 2 * Y;
    } else {
      v = v + 2 * (Y - X); y++;
    }
    x++;
  }

  vtrace2(X, Y, x, y, v);
  return v;
}