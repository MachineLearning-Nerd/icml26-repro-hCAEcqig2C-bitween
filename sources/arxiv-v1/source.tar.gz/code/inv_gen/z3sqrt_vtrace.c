float z3sqrt(float a) {
  assume(a >= 1);

  float x = a;
  float q = 0.5 * (x + a / x);
  float err = 0.0001;

  while(x - q > err or q - x > err){
    vtrace1(a, x, err, q);

    x = q;
    q = 0.5 * (x + a / x);
  }

  return q;
}